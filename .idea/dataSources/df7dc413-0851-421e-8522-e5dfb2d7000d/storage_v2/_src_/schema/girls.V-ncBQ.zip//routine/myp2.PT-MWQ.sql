create
    definer = root@localhost procedure myp2(IN beautyName varchar(20))
begin
    select bo.*
          from boys bo right join beauty b on b.id = bo.id
        where b.name = beautyName;

end;

