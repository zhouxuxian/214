create
    definer = root@localhost procedure myp4(IN beautyName varchar(20), OUT boyName varchar(20))
begin

    select bo.boyname into boyName from boys bo inner join beauty b on b.id=bo.id
    where b.name = beautyName;


    end;

